
/*
╔══════════════════════════════════════╗
║          DAKOS BOT CONFIG             ║
║          WhatsApp Bot - Node.js      ║
╚══════════════════════════════════════╝
*/

// ==========================================
// معلومات المالك والمطور
// ==========================================

global.ownernomer = "212639392740";

global.dev = [
    "212639392740"
];

global.ownername = "dakos";

global.ytname = "dakos";

global.socialm = "Developer: @fooot567";

global.location = "Morocco";

global.ownernumber = "212639392740";

global.botname = "Dakos Bot 🌴";

// وسيلة التواصل مع المطور
global.developerContact = "@fooot567";

global.telegram = "";

global.youtube = "";

// ==========================================
// إعدادات الملصقات (Stickers)
// ==========================================

global.packname = "Dakos Bot";

global.author = "Dakos Bot 🌴\nDeveloper: @fooot567";

// ==========================================
// إعدادات المظهر
// ==========================================

global.themeemoji = "🌴";

global.wm = "Dakos Bot";

// ==========================================
// روابط التواصل
// ==========================================

global.link = "";

global.idch = "";

// ==========================================
// قاعدة البيانات
// ==========================================

global.baileysDB = "baileysDB.json";

global.botDb = "database.json";

// ==========================================
// بادئة الأوامر
// ==========================================

// استخدام النقطة فقط
global.prefa = ["."];

// ==========================================
// حدود الاستخدام
// ==========================================

global.limitawal = {
    premium: 1000,
    free: 100
};

// ==========================================
// نوع القائمة
// ==========================================

// v1 = قائمة بصورة
// v2 = روابط وصورة
// v3 = قائمة فيديو
// v4 = قائمة إنهاء الاتصال

global.typemenu = "v3";

// ==========================================
// الرسائل العامة
// ==========================================

global.mess = {
    success: "تم بنجاح ✓",

    admin: "هذا الأمر مخصص لمشرفي المجموعة فقط.",

    botAdmin: "يجب أن يكون البوت مشرفًا في المجموعة لاستخدام هذا الأمر.",

    OnlyOwner: "هذا الأمر مخصص لمالك البوت فقط.",

    OnlyGrup: "هذا الأمر متاح داخل المجموعات فقط.",

    private: "هذا الأمر متاح في المحادثات الخاصة فقط.",

    wait: "⏳ يرجى الانتظار قليلًا...",

    notregist: "أنت غير مسجل في قاعدة بيانات البوت. يرجى التسجيل أولًا.",

    premium: "هذه الميزة مخصصة للمستخدمين المميزين."
};

// ==========================================
// إعدادات إضافية افتراضية
// ==========================================

global.botMode = "public";

global.autoRead = false;

global.autoTyping = false;

global.autoRecording = false;

// ==========================================
// تصدير الإعدادات الإضافية
// ==========================================

module.exports = {
    banner: [],
    botname: global.botname,
    ownername: global.ownername,
    ownernumber: global.ownernumber,
    developerContact: global.developerContact,
    typemenu: global.typemenu,
    prefa: global.prefa,
    limitawal: global.limitawal,
    mess: global.mess
};

// ==========================================
// إعادة تحميل الإعدادات عند تعديل الملف
// ==========================================

const fs = require("fs");

const file = require.resolve(__filename);

fs.watchFile(file, () => {
    fs.unwatchFile(file);

    console.log("[DAKOS BOT] Configuration updated.");

    delete require.cache[file];

    try {
        require(file);
    } catch (error) {
        console.error(
            "[DAKOS BOT] Configuration reload failed:",
            error.message
        );
    }
});
