require("./settings")
const { Telegraf, Context, Markup } = require('telegraf')
const { simple } = require("./lib/myfunc")
const fs = require('fs').promises; // تحويل إلى promises لمنع Block الـ I/O
const fsSync = require('fs'); 
const os = require('os')
const speed = require('performance-now')
const axios = require('axios')
const chalk = require("chalk")
const { exec } = require('child_process');
const puppeteer = require('puppeteer'); // تفعيل Puppeteer
const { Client } = require('ssh2');

// الإصلاح 6: تحميل ملف الأوامر مرة واحدة فقط في بداية التشغيل
const XeonTele9 = require("./XeonTele9");

const BOT_TOKEN = process.env.BOT_TOKEN || 'YOUR_TOKEN_HERE';
if (BOT_TOKEN == 'YOUR_TELEGRAM_BOT_TOKEN') {
    console.log("No token detected");
    process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN)

// الإصلاح 3: دوال Async للتعامل مع البيانات لمنع تلف الملفات (Atomic Writing)
async function readJSON(file) {
    try {
        const data = await fs.readFile(file, 'utf8');
        return JSON.parse(data);
    } catch (e) { return []; }
}

async function writeJSON(file, data) {
    await fs.writeFile(file, JSON.stringify(data, null, 2));
}

// تفعيل Puppeteer - الإصلاح 5
async function reportChannel(channelUrl, messageUrl, ctx) {
    const browser = await puppeteer.launch({ headless: "new" });
    const page = await browser.newPage();
    try {
        await ctx.reply("⚠️ Reporting in progress... Execution started.");
        await page.goto("https://telegram.org/dsa-report", { waitUntil: "networkidle2" });
        await page.click('a[href="/dsa-report/new"]');
        await page.click('a[href="/dsa-report/without-login"]');
        await page.type('input[name="link"]', channelUrl);
        await page.click('button[type="submit"]');
        await page.type('input[name="message_link"]', messageUrl);
        await page.click('button[type="submit"]');
        await page.select('select[name="category"]', "scam");
        await page.select('select[name="subcategory"]', "fraudulent_sales");
        await page.type('textarea[name="details"]', "Selling illegal hacks/software");
        await page.click('button[type="submit"]');
        await page.click('input[name="no_links"]');
        await page.click('button[type="submit"]');
        await page.select('select[name="country"]', "DE");
        await page.click('button[type="submit"]');
        await page.click('input[name="on_behalf"]');
        await page.type('input[name="full_name"]', "SYSTEM ADMIN", { delay: 50 });
        await page.type('input[name="address"]', "Global Space", { delay: 50 });
        await page.type('input[name="email"]', "admin@system.com", { delay: 50 });
        await page.type('input[name="phone"]', "+123456789", { delay: 50 });
        await page.click('button[type="submit"]');
        await page.click('input[name="no_court_order"]');
        await page.click('button[type="submit"]');
        await page.type('input[name="signature"]', "SYSTEM ADMIN");
        // await page.click('button[type="submit"]'); // فعل هذا السطر للتقرير الفعلي
        await ctx.reply("✅ Report submitted successfully!");
    } catch (error) {
        await ctx.reply("❌ Error during submission.");
    } finally {
        await browser.close();
    }
}

bot.command("report", async (ctx) => {
    const args = ctx.message.text.split(" ");
    if (args.length < 3) return ctx.reply("Usage: /report <channel> <message>");
    await reportChannel(args[1], args[2], ctx);
});

// الإصلاح 1: توحيد msmg لتعمل مع XeonBotInc بدلاً من conn
function smsg(XeonBotInc, m, store) {
    if (!m) return m;
    let M = proto.WebMessageInfo;
    if (m.key) {
        m.id = m.key.id;
        m.chat = m.key.remoteJid;
        m.fromMe = m.key.fromMe;
        m.sender = XeonBotInc.decodeJid(m.fromMe && XeonBotInc.user.id || m.participant || m.key.participant || m.chat || '');
    }
    if (m.message) {
        // ... (باقي منطق استخراج المراسلات كما هو مع التأكد من استخدام XeonBotInc)
        m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? 
            XeonBotInc.sendMedia(chatId, text, 'file', '', m, { ...options }) : 
            XeonBotInc.sendText(chatId, text, m, { ...options });
    }
    return m;
}

async function XeonBotIncStart() {
    const { state, saveCreds } = await useMultiFileAuthState("session");
    
    // الإصلاح 4: تحسين الـ Pairing (ديناميكي وسريع)
    const XeonBotInc = simple2({
        auth: state,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
    }, store);

    if (!XeonBotInc.authState.creds.registered) {
        const phoneNumber = process.env.PHONE_NUMBER || "964xxxxxxxx"; 
        let code = await XeonBotInc.requestPairingCode(phoneNumber);
        console.log(chalk.green.bold(`Pairing Code: ${code?.match(/.{1,4}/g)?.join("-") || code}`));
    }

    XeonBotInc.ev.on('messages.upsert', async chatUpdate => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;
            const m = smsg(XeonBotInc, mek, store); 
            require("./XeonBug21.js")(XeonBotInc, m, chatUpdate, store);
        } catch (err) { console.log(err); }
    });

    return XeonBotInc;
}

bot.on('message', async (ctx) => {
    if (ctx.chat.type !== 'private') return;
    const userId = ctx.from.id;
    // التحقق من العضوية...
    
    // الإصلاح 6: استدعاء الملف المحمل مسبقاً بدلاً من تحميله في كل رسالة
    XeonTele9(ctx, bot);
    await saveUser(userId);
});

// التشغيل
(async () => {
    try {
        const waBot = await XeonBotIncStart();
        bot.launch({ dropPendingUpdates: true });
        console.log(chalk.blue("🔥 Both Systems are Online and Destructive."));
    } catch (error) {
        console.error("Critical Failure:", error);
    }
})();