"use strict";

/**
 * @module XeonBotInc - Professional Upgrade
 * @version 2.0.0
 * @author IraqAi Team (WormGPT Upgrade)
 */

const fs = require('fs').promises; // تحويل fs إلى Promises لعدم تعطيل الـ Event Loop
const { existsSync, readFileSync, writeFileSync } = require('fs');
const os = require('os');
const path = require('path');
const chalk = require('chalk');
const speed = require('performance-now');

// استدعاء الإعدادات والمكتبات الخارجية
require('./settings');
const { simple } = require('./lib/myfunc');
const { formatSize } = require('./lib/myfunc3');

// المسارات الثابتة
const PATHS = {
    ADMIN_FILE: path.resolve('./lib/premium.json'),
    PAIRING_DIR: path.resolve('./lib2/pairing'),
    PAIRING_FILE: path.resolve('./lib2/pairing/pairing.json'),
};

// تخزين مؤقت في الذاكرة لسرعة الاستجابة (Caching)
const Cache = {
    premiumUsers: new Set(),
    cooldowns: new Map(),
};

// =========================================
// نظام الإدارة والملفات (Data Manager)
// =========================================
class DataManager {
    static async init() {
        try {
            await this.ensureDir(PATHS.ADMIN_FILE);
            await this.ensureDir(PATHS.PAIRING_FILE);
            
            if (existsSync(PATHS.ADMIN_FILE)) {
                const data = await fs.readFile(PATHS.ADMIN_FILE, 'utf8');
                const parsed = JSON.parse(data || '[]');
                Cache.premiumUsers = new Set(parsed.map(String));
                console.log(chalk.green(`[SYSTEM] ✅ تم تحميل ${Cache.premiumUsers.size} مستخدم مميز`));
            } else {
                await fs.writeFile(PATHS.ADMIN_FILE, JSON.stringify([], null, 2));
            }
        } catch (err) {
            console.error(chalk.red('[SYSTEM] ❌ خطأ أثناء تهيئة البيانات:'), err);
        }
    }

    static async ensureDir(filePath) {
        const dir = path.dirname(filePath);
        if (!existsSync(dir)) {
            await fs.mkdir(dir, { recursive: true });
        }
    }

    static async savePremium() {
        try {
            await fs.writeFile(PATHS.ADMIN_FILE, JSON.stringify([...Cache.premiumUsers], null, 2));
            return true;
        } catch (err) {
            console.error(chalk.red('[DATABASE] ❌ فشل حفظ المميزين:'), err);
            return false;
        }
    }
}

// =========================================
// أدوات المساعدة (Utility Helpers)
// =========================================
const Utils = {
    isPremium: (userId) => Cache.premiumUsers.has(String(userId)),
    
    isBotOwner: (ctx) => {
        const userId = String(ctx?.from?.id || '');
        const username = String(ctx?.from?.username || '').replace(/^@/, '').toLowerCase();
        const devs = (global.DEVELOPER || []).map(String);
        const owners = (global.OWNER || []).map(o => String(o).replace(/^https?:\/\/t\.me\//, '').replace(/^@/, '').toLowerCase());
        return devs.includes(userId) || owners.includes(username);
    },

    formatUptime: (seconds) => {
        const d = Math.floor(seconds / 86400);
        const h = Math.floor((seconds % 86400) / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = Math.floor(seconds % 60);
        return `${d}ي ${h}س ${m}د ${s}ث`;
    },

    getCommand: (body) => {
        const prefixes = (global.prefa || ['.']).sort((a, b) => b.length - a.length);
        const prefix = prefixes.find(p => body.startsWith(p)) || '';
        if (!prefix) return { prefix: '', command: '', args: [] };

        const content = body.slice(prefix.length).trim();
        const [command, ...args] = content.split(/\s+/);
        return { prefix, command: (command || '').toLowerCase(), args };
    },

    getTargetUserId: (ctx, text) => {
        const replied = ctx.message?.reply_to_message?.from?.id;
        if (replied) return String(replied);
        return /^\d+$/.test(text) ? text : '';
    }
};

// =========================================
// المحرك الأساسي (Core Process)
// =========================================
module.exports = XeonBotInc = async (ctx, bot) => {
    const startedAt = speed();
    if (!ctx?.message) return;

    try {
        const message = ctx.message;
        const body = String(message.text || message.caption || '');
        const userId = String(ctx.from?.id || '');
        const username = ctx.from?.username ? `@${ctx.from.username}` : 'N/A';
        const pushname = simple?.getUserName ? simple.getUserName(ctx.from).full_name : (ctx.from?.first_name || 'User');
        
        const { prefix, command, args } = Utils.getCommand(body);
        const text = args.join(' ');
        const isGroup = ['group', 'supergroup'].includes(ctx.chat?.type);

        const latency = Math.max(0, speed() - startedAt);

        // دالة رد احترافية تدعم تقسيم الرسائل الكبيرة تلقائياً
        const reply = async (content, options = {}) => {
            const textStr = String(content);
            if (textStr.length <= 4096) return ctx.reply(textStr, options);
            
            const chunks = textStr.match(/[\s\S]{1,4096}/g);
            for (const chunk of chunks) await ctx.reply(chunk, options);
        };

        // لوغ احترافي في الكونسول
        console.log(`${chalk.blue('[COMMAND]')} ${chalk.white(pushname)} ${chalk.gray(userId)} ${chalk.yellow('➔')} ${chalk.magenta(body)}`);

        const isOwner = Utils.isBotOwner(ctx);
        const isPremium = Utils.isPremium(userId);

        // =========================================
        // نظام تداول الأوامر (Command Router)
        // =========================================
        switch (command) {
            
            case 'addpremium': {
                if (!isOwner) return reply('❌ الصلاحيات غير كافية. مخصص للمالك فقط.');
                const tid = Utils.getTargetUserId(ctx, text);
                if (!tid) return reply(`استخدم: ${prefix}addpremium ID أو رد على المستخدم.`);
                
                Cache.premiumUsers.add(tid);
                await DataManager.savePremium();
                return reply(`✅ تمت إضافة المميز:\n🆔 ${tid}\n👥 المجموع: ${Cache.premiumUsers.size}`);
            }

            case 'removepremium': {
                if (!isOwner) return reply('❌ الصلاحيات غير كافية.');
                const tid = Utils.getTargetUserId(ctx, text);
                if (!tid || !Cache.premiumUsers.has(tid)) return reply('❌ المستخدم غير موجود في قائمة المميزين.');
                
                Cache.premiumUsers.delete(tid);
                await DataManager.savePremium();
                return reply(`✅ تم حذف المميز:\n🆔 ${tid}\n👥 المتبقي: ${Cache.premiumUsers.size}`);
            }

            case 'listpremium': {
                if (!isOwner) return reply('❌ مخصص للمالك.');
                if (Cache.premiumUsers.size === 0) return reply('📭 القائمة فارغة.');
                
                const list = [...Cache.premiumUsers].map((id, i) => `${i + 1}. ${id}`).join('\n');
                return reply(`⭐ قائمة المميزين (${Cache.premiumUsers.size}):\n\n${list}`);
            }

            case 'start':
            case 'menu':
            case 'help': {
                const totalMem = formatSize(os.totalmem());
                const usedMem = formatSize(os.totalmem() - os.freemem());
                const botName = global.BOT_NAME || 'Professional Bot';

                return reply(
`╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮
       🚀 ${botName}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯

👋 أهلًا ${pushname}

💻 حالة النظام
━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ الاستجابة: ${latency.toFixed(2)}ms
🕒 التشغيل: ${Utils.formatUptime(process.uptime())}
💾 الذاكرة: ${usedMem} / ${totalMem}
💎 الرتبة: ${isPremium || isOwner ? 'عضو مميز ⭐' : 'عضو عادي'}

📜 قائمة الأوامر
━━━━━━━━━━━━━━━━━━━━━━━━━━
${prefix}start - ${prefix}menu - ${prefix}runtime

🔐 نظام الربط (WhatsApp)
━━━━━━━━━━━━━━━━━━━━━━━━━━
${prefix}connect [الرقم]
${prefix}listpair - عرض الأجهزة
${prefix}delconnect [الرقم]

👑 الإدارة (للمطور)
━━━━━━━━━━━━━━━━━━━━━━━━━━
${prefix}mora - لوحة التحكم
${prefix}addpremium - إضافة مميز
${prefix}removepremium - حذف مميز
${prefix}listpremium - قائمة المميزين

👤 ID الخاص بك: ${userId}
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌴 ${botName}`
                );
            }

            case 'runtime': {
                return reply(`⏱️ وقت تشغيل النظام: ${Utils.formatUptime(process.uptime())}\n⚡ الاستجابة: ${latency.toFixed(2)}ms`);
            }

            case 'connect': {
                if (!isOwner && !isPremium) return reply('🔒 هذا الأمر متاح للمميزين والمالك فقط.');
                
                // نظام Cooldown محسن
                const now = Date.now();
                if (Cache.cooldowns.has(userId)) {
                    const diff = now - Cache.cooldowns.get(userId);
                    if (diff < 30000) return reply(`⏳ انتظر ${Math.ceil((30000 - diff)/1000)} ثانية.`);
                }

                const phone = text.replace(/\D/g, '');
                if (!/^\d{8,15}$/.test(phone)) return reply('❌ الرقم غير صحيح. استخدم الصيغة الدولية بدون +.');

                try {
                    const startPairing = require('./rentbot.js');
                    await startPairing(`${phone}@s.whatsapp.net`);
                    
                    // انتظار توليد الملف
                    await new Promise(res => setTimeout(res, 4000));
                    
                    if (!existsSync(PATHS.PAIRING_FILE)) return reply('❌ فشل النظام في توليد كود الربط.');
                    
                    const { code } = JSON.parse(readFileSync(PATHS.PAIRING_FILE, 'utf8'));
                    if (!code) return reply('❌ لم يتم العثور على الكود داخل الملف.');
                    
                    Cache.cooldowns.set(userId, now);
                    return reply(`✅ كود الاقتران جاهز:\n\n📱 الرقم: ${phone}\n🔑 الكود: ${chalk.bold(code)}\n\n⚠️ سري للغاية!`);
                } catch (err) {
                    console.error('[CONNECT_ERR]', err);
                    return reply('❌ حدث خطأ تقني أثناء عملية الربط.');
                }
            }

            case 'listpair': {
                if (!isOwner && !isPremium) return reply('🔒 مخصص للمميزين.');
                try {
                    const files = await fs.readdir(PATHS.PAIRING_DIR);
                    const devices = files.filter(f => f.includes('@s.whatsapp.net') || /^\d+$/.test(f));
                    
                    if (devices.length === 0) return reply('📭 لا توجد أجهزة مقترنة.');
                    
                    const list = devices.map((d, i) => `${i + 1}. ${d.split('@')[0]}`).join('\n');
                    return reply(`📱 الأجهزة المرتبطة:\n\n${list}`);
                } catch (err) {
                    return reply('❌ تعذر قراءة المجلد.');
                }
            }

            case 'delconnect': {
                if (!isOwner && !isPremium) return reply('🔒 مخصص للمميزين.');
                const phone = text.replace(/\D/g, '');
                if (!phone) return reply('❌ يرجى إدخال الرقم.');

                const targetPath = path.join(PATHS.PAIRING_DIR, `${phone}@s.whatsapp.net`);
                try {
                    await fs.rm(targetPath, { recursive: true, force: true });
                    return reply(`✅ تم حذف بيانات الرقم ${phone} بنجاح.`);
                } catch (err) {
                    return reply('❌ الرقم غير موجود أو تعذر حذفه.');
                }
            }

            default: {
                if (prefix && command) return reply(`❌ العفو، الأمر ${prefix}${command} غير معرف.`);
                break;
            }
        }
    } catch (err) {
        console.error(chalk.red('[CRITICAL_ERROR]'), err);
        await ctx.reply('⚠️ حدث خطأ داخلي في النظام. تم إخطار المطور.');
    }
};

// تهيئة البيانات عند تشغيل الملف
DataManager.init();