
const fs = require("fs");
const chalk = require("chalk");

// =====================================
// DAKOS BOT 🌴 - SETTINGS
// =====================================

// ضع الرمز الجديد في متغير البيئة BOT_TOKEN
global.BOT_TOKEN = process.env.BOT_TOKEN || "8904036585:AAGlah1ClXctxnk85TR7YSLvbfE-j0E8yfY";

// معلومات البوت
global.BOT_NAME = "Dakos Bot 🌴";
global.OWNER_NAME = "dakos";
global.OWNER = ["fooot567"];

// Telegram ID للمطوّر
global.DEVELOPER = ["5004642768"];

// صورة البوت
global.pp = "";

// =====================================
// GROUP / CHANNEL APPROVAL
// مؤجل حاليًا
// =====================================

global.GROUP_ID = null;
global.CHANNEL_ID = null;
global.GROUP_LINK = "";
global.CHANNEL_INVITE_LINK = "";

// روابط التواصل
global.WHATSAPP_LINK = "https://wa.me/212639392740";
global.YOUTUBE_LINK = "";
global.INSTAGRAM_LINK = "";

// =====================================
// WHATSAPP OWNER
// =====================================

global.owner = ["212639392740"];

// =====================================
// PREFIX AND LIMITS
// =====================================

global.prefa = ["."];
global.limitawal = {
    free: 100,
    premium: 1000
};

// =====================================
// LANGUAGE
// =====================================

const { english } = require("./lib");
global.language = english;
global.lang = global.language;

// =====================================
// FILE WATCHER
// =====================================

const file = require.resolve(__filename);

fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright("Updated settings.js"));
    delete require.cache[file];
    require(file);
});
